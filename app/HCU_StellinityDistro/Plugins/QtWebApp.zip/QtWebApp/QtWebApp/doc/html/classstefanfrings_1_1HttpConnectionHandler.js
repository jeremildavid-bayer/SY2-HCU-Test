var classstefanfrings_1_1HttpConnectionHandler =
[
    [ "HttpConnectionHandler", "classstefanfrings_1_1HttpConnectionHandler.html#a52a1397d46ac3662f325846904f9c5f2", null ],
    [ "~HttpConnectionHandler", "classstefanfrings_1_1HttpConnectionHandler.html#af47c5713b7e92040d59803bd7c99c9f5", null ],
    [ "handleConnection", "classstefanfrings_1_1HttpConnectionHandler.html#ad4d57782218e761cd002e84b3707579d", null ],
    [ "isBusy", "classstefanfrings_1_1HttpConnectionHandler.html#a3ce005483981faf3b1b5cabf1fe6c24f", null ],
    [ "setBusy", "classstefanfrings_1_1HttpConnectionHandler.html#a7fcffe53d6604499fbb298bbc0fa453e", null ]
];