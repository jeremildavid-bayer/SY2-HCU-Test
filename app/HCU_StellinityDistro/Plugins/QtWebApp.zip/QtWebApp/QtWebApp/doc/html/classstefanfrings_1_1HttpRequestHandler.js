var classstefanfrings_1_1HttpRequestHandler =
[
    [ "HttpRequestHandler", "classstefanfrings_1_1HttpRequestHandler.html#a436ce22e3f9d0187e1718e010f0b8a32", null ],
    [ "~HttpRequestHandler", "classstefanfrings_1_1HttpRequestHandler.html#a32bf6b0e36dbdb4cd0525d2c4b54fdec", null ],
    [ "service", "classstefanfrings_1_1HttpRequestHandler.html#a0a7210907152c46b8b5a47feb64cf6bd", null ]
];