Supported only for Qt 5 projects since Qt Multimedia module has been removed in Qt 6.

In case it gets re-supported for Qt 6, the examples will be updated.
