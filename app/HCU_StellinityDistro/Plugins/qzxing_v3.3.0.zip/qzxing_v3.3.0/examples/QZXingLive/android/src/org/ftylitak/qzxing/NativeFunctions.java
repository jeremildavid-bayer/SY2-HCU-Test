package org.ftylitak.qzxing;

public class NativeFunctions {
    public static native void onPermissionsGranted();
    public static native void onPermissionsDenied();
}
